USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[BorrarPelicula]    Script Date: 24/8/2022 00:30:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 2
CREATE procedure [dbo].[BorrarPelicula]
	@cod_pelicula int
as

	update tPelicula
	set cant_disponibles_alquiler = 0,
		cant_disponibles_venta = 0
	where cod_pelicula = @cod_pelicula
GO


