USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[VenderPelicula]    Script Date: 24/8/2022 00:33:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 5
CREATE procedure [dbo].[VenderPelicula]
	@cod_pelicula int,
	@cod_usuario	int,
	@precio	numeric(18,2),
	@fecha	datetime
as
	if((select cant_disponibles_venta from tpelicula where cod_pelicula = @cod_pelicula) = 0)
		raiserror('No hay peliculas disponibles para vender',16,1)
	else
	begin

	insert into tVentas (cod_pelicula, cod_usuario, precio, fecha)
		values(@cod_pelicula, @cod_usuario, @precio, @fecha)

	update tPelicula
	set cant_disponibles_venta = cant_disponibles_venta - 1
	where cod_pelicula = @cod_pelicula
	end
GO


