USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[CrearPelicula]    Script Date: 24/8/2022 00:31:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--PUNTO 2
CREATE procedure [dbo].[CrearPelicula]
	@txt_desc varchar(500) null,
	@cant_disponibles_alquiler int null,
	@cant_disponibles_venta int null,
	@precio_alquiler numeric(18,2) null,
	@precio_venta numeric(18,2)
as

	insert into tPelicula (txt_desc,cant_disponibles_alquiler,
					cant_disponibles_venta, precio_alquiler,
					precio_venta)
	values(@txt_desc,@cant_disponibles_alquiler,
					@cant_disponibles_venta, @precio_alquiler,
					@precio_venta)
GO


