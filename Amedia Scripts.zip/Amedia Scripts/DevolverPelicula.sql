USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[DevolverPelicula]    Script Date: 24/8/2022 00:31:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--PUNTO 10
CREATE procedure [dbo].[DevolverPelicula]
	@cod_alquiler int
as

	declare @cod_pelicula int

	set @cod_pelicula = (select cod_pelicula from talquileres where cod_alquiler = @cod_alquiler)

	update tAlquileres set devuelta=1 where cod_alquiler = @cod_alquiler

	Update tPelicula
	set cant_disponibles_alquiler = cant_disponibles_alquiler + 1
	where cod_pelicula = @cod_pelicula
GO


