USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[StockAlquiler]    Script Date: 24/8/2022 00:32:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 6
CREATE procedure [dbo].[StockAlquiler]
as

	select *
	from tPelicula
	where cant_disponibles_alquiler > 0
GO


