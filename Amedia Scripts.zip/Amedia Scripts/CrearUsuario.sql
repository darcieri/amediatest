USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[CrearUsuario]    Script Date: 24/8/2022 00:31:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 1
CREATE procedure [dbo].[CrearUsuario]
	@txt_user varchar(50),
	@txt_password varchar (50),
	@txt_nombre varchar(200),
	@txt_apellido varchar(200),
	@nro_doc varchar (50),
	@cod_rol int
as

	if not exists(select 1 from dbo.tUsers where ltrim(rtrim(nro_doc)) = ltrim(rtrim(@nro_doc)))
	begin
		insert into tUsers (txt_user, txt_password, txt_nombre,
						txt_apellido, nro_doc, cod_rol, sn_activo)
		values(@txt_user, @txt_password, @txt_nombre,
				@txt_apellido, @nro_doc, @cod_rol, 1)
	end
	else
		raiserror('Ya existe otro usuario con el mismo nro. de documento',16,1)
GO


