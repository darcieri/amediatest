USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[VerPeliculasAlquiladas]    Script Date: 24/8/2022 00:33:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 12
CREATE procedure [dbo].[VerPeliculasAlquiladas]
	@cod_usuario	int
as

	select *
	from tAlquileres
	where cod_usuario = @cod_usuario
GO


