USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[StockVenta]    Script Date: 24/8/2022 00:32:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 7
CREATE procedure [dbo].[StockVenta]
as

	select *
	from tPelicula
	where cant_disponibles_venta > 0
GO


