USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[ModificarPelicula]    Script Date: 24/8/2022 00:32:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 2

CREATE procedure [dbo].[ModificarPelicula]
	@cod_pelicula int,
	@txt_desc varchar(500) null,
	@cant_disponibles_alquiler int null,
	@cant_disponibles_venta int null,
	@precio_alquiler numeric(18,2) null,
	@precio_venta numeric(18,2)
as

	update tPelicula
	set txt_desc = @txt_desc,
		cant_disponibles_alquiler = @cant_disponibles_alquiler,
		cant_disponibles_venta = @cant_disponibles_venta,
		precio_alquiler = @precio_alquiler,
		precio_venta = @precio_venta
	where cod_pelicula = @cod_pelicula
GO


