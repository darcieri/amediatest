USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[CrearGenero]    Script Date: 24/8/2022 00:30:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--PUNTO 3
CREATE procedure [dbo].[CrearGenero]
	@txt_desc varchar(500) null
as

	insert into tGenero (txt_desc)
	values(@txt_desc)
GO


