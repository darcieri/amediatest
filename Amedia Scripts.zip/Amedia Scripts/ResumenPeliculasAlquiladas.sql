USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[ResumenPeliculasAlquiladas]    Script Date: 24/8/2022 00:32:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 13
CREATE procedure [dbo].[ResumenPeliculasAlquiladas]
as


	select a.cod_pelicula, COUNT(b.cod_pelicula), SUM(isnull(b.precio,0)) as precio
	from tPelicula a
	left join tAlquileres b on a.cod_pelicula = b.cod_pelicula
	group by a.cod_pelicula
GO


