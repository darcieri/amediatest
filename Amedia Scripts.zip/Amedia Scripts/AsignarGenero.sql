USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[AsignarGenero]    Script Date: 24/8/2022 00:30:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 4
CREATE procedure [dbo].[AsignarGenero]
	@cod_pelicula int,
	@cod_genero	int
as

	if not exists(select 1 from tGeneroPelicula where cod_pelicula = @cod_pelicula)
		insert into tGeneroPelicula (cod_pelicula, cod_genero)
		values(@cod_pelicula, @cod_genero)
	else
		raiserror('La pelicula ya tiene un genero asignado',16,1)
GO


