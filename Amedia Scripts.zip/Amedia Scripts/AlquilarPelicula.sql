USE [TestCrud]
GO

/****** Object:  StoredProcedure [dbo].[AlquilarPelicula]    Script Date: 24/8/2022 00:29:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--PUNTO 5
CREATE procedure [dbo].[AlquilarPelicula]
	@cod_pelicula int,
	@cod_usuario	int,
	@precio	numeric(18,2)
as

	if((select cant_disponibles_alquiler from tpelicula where cod_pelicula = @cod_pelicula) = 0)
		raiserror('No hay peliculas disponibles para alquilar',16,1)
	else
	begin
	insert into tAlquileres (cod_pelicula, cod_usuario, precio, fecha)
		values(@cod_pelicula, @cod_usuario, @precio, GETDATE())

	update tPelicula
	set cant_disponibles_alquiler = cant_disponibles_alquiler - 1
	where cod_pelicula = @cod_pelicula
	end
GO


