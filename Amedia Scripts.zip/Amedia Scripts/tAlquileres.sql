USE [TestCrud]
GO

/****** Object:  Table [dbo].[tAlquileres]    Script Date: 24/8/2022 00:28:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tAlquileres](
	[cod_alquiler] [int] IDENTITY(1,1) NOT NULL,
	[cod_pelicula] [int] NOT NULL,
	[cod_usuario] [int] NOT NULL,
	[precio] [numeric](18, 2) NOT NULL,
	[fecha] [datetime] NOT NULL,
	[devuelta] [bit] NOT NULL,
 CONSTRAINT [PK_tAlquileres] PRIMARY KEY CLUSTERED 
(
	[cod_alquiler] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tAlquileres] ADD  CONSTRAINT [DF_tAlquileres_devuelta]  DEFAULT ((0)) FOR [devuelta]
GO

ALTER TABLE [dbo].[tAlquileres]  WITH CHECK ADD  CONSTRAINT [FK_tAlquileres_tPelicula] FOREIGN KEY([cod_pelicula])
REFERENCES [dbo].[tPelicula] ([cod_pelicula])
GO

ALTER TABLE [dbo].[tAlquileres] CHECK CONSTRAINT [FK_tAlquileres_tPelicula]
GO

ALTER TABLE [dbo].[tAlquileres]  WITH CHECK ADD  CONSTRAINT [FK_tAlquileres_tUsers] FOREIGN KEY([cod_usuario])
REFERENCES [dbo].[tUsers] ([cod_usuario])
GO

ALTER TABLE [dbo].[tAlquileres] CHECK CONSTRAINT [FK_tAlquileres_tUsers]
GO


