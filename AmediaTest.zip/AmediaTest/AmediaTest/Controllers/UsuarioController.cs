﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmediaTest.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index(Models.UsuarioModel _model)
        {
            ContextDb.AppDbContext db = new ContextDb.AppDbContext();

            var query = db.TUsers
                .Select(s => new
                {
                    s.CodRol,
                    s.CodUsuario,
                    s.NroDoc,
                    s.SnActivo,
                    s.TxtApellido,
                    s.TxtNombre,
                    s.TxtUser,
                    s.TxtPassword,
                    RolDesc = s.CodRolNavigation.TxtDesc

                })
                .ToList();
            
            var model = new Models.UsuarioModel();
            var listaUsuarios = new List<Models.UsuarioModel>();


            foreach(var obj in query)
            {
                var usuarioModel = new Models.UsuarioModel();
                usuarioModel.CodRol = obj.CodRol;
                usuarioModel.CodUsuario = obj.CodUsuario;
                usuarioModel.NroDoc = obj.NroDoc;
                usuarioModel.SnActivo =  Convert.ToBoolean( obj.SnActivo.Value);
                usuarioModel.TxtApellido = obj.TxtApellido;
                usuarioModel.TxtNombre = obj.TxtNombre;
                usuarioModel.TxtUser = obj.TxtUser;
                usuarioModel.TxtPassword = obj.TxtPassword;
                usuarioModel.RolDesc = obj.RolDesc;

                listaUsuarios.Add(usuarioModel);
            }

            model.ListaUsuarios = listaUsuarios;
            model.TxtUser = _model.TxtUser;
            return View(model);
        }

        public ActionResult Details(int codUsuario)
        {

            var model = GetUsuario(codUsuario);

            model.ListaRoles = new SelectList(GetRoles(), "CodRol", "TxtDesc");


            return View(model);
        }

        public ActionResult Create()
        {
            Models.UsuarioModel model = new Models.UsuarioModel();

            model.ListaRoles = new SelectList(GetRoles(),"CodRol","TxtDesc");

            return View(model);
        }

        // POST: /Clientes/Create
        [HttpPost]
        public ActionResult Create(Models.UsuarioModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ContextDb.AppDbContext db = new ContextDb.AppDbContext();

                    var query = db.TUsers.Where(w => w.TxtUser == model.TxtUser.Trim()).FirstOrDefault();


                    if (query == null)
                    {
                        ContextDb.TUser nuevoUsuario = new ContextDb.TUser();
                        nuevoUsuario.CodRol = model.CodRol;
                        nuevoUsuario.NroDoc = model.NroDoc;
                        nuevoUsuario.SnActivo = 1;
                        nuevoUsuario.TxtApellido = model.TxtApellido;
                        nuevoUsuario.TxtNombre = model.TxtNombre;
                        nuevoUsuario.TxtUser = model.TxtUser;
                        nuevoUsuario.TxtPassword = model.TxtPassword;

                        db.Add(nuevoUsuario);
                        db.SaveChanges();

                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Ya existe otro usuario con el mismo UserName.");
                        
                    }
                }

                model.ListaRoles = new SelectList(GetRoles(),"CodRol","TxtDesc");

                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);

                return View(model);
            }
        }
        
        public ActionResult Edit(int codUsuario)
        {
            var model = GetUsuario(codUsuario);

            model.ListaRoles = new SelectList(GetRoles(), "CodRol", "TxtDesc");


            return View(model);
        }

        private List<ContextDb.TRol> GetRoles()
        {
            ContextDb.AppDbContext db = new ContextDb.AppDbContext();

            var query = db.TRols.OrderBy(o => o.TxtDesc).ToList();

            return query;
        }

        private Models.UsuarioModel GetUsuario(int codUsuario)
        {
            try
            {
                ContextDb.AppDbContext db = new ContextDb.AppDbContext();
                var model = new Models.UsuarioModel();


                var query = db.TUsers.Where(w => w.CodUsuario == codUsuario)
                    .Select(s => new
                    {
                        s.CodRol,
                        s.CodUsuario,
                        s.NroDoc,
                        s.SnActivo,
                        s.TxtApellido,
                        s.TxtNombre,
                        s.TxtUser,
                        s.TxtPassword,
                        Rol = s.CodRolNavigation.TxtDesc

                    }).FirstOrDefault();

                if (query != null)
                {
                    model.CodRol = query.CodRol;
                    model.CodUsuario = query.CodUsuario;
                    model.NroDoc = query.NroDoc;
                    model.SnActivo = Convert.ToBoolean(query.SnActivo.Value);
                    model.TxtApellido = query.TxtApellido;
                    model.TxtNombre = query.TxtNombre;
                    model.TxtUser = query.TxtUser;
                    model.TxtPassword = query.TxtPassword;
                    model.RolDesc = query.Rol;

                }
                else
                {
                    throw new ApplicationException("No se puede obtener los datos del usuario.");
                }

                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // POST: /Clientes/Edit/5
        [HttpPost]
        public ActionResult Edit(Models.UsuarioModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ContextDb.AppDbContext db = new ContextDb.AppDbContext();

                    var query = db.TUsers.Where(w => w.CodUsuario == model.CodUsuario).FirstOrDefault();


                    if (query != null)
                    {

                        var query2 = db.TUsers.Where(w => w.TxtUser == model.TxtUser.Trim()).FirstOrDefault();

                        if (query2 != null && query2.CodUsuario != model.CodUsuario)
                        {
                            ModelState.AddModelError("", "Ya existe otro usuario con el mismo UserName.");
                        }
                        else
                        {
                            query.CodRol = model.CodRol;
                            query.NroDoc = model.NroDoc;
                            query.SnActivo = Convert.ToInt32( model.SnActivo);
                            query.TxtApellido = model.TxtApellido;
                            query.TxtNombre = model.TxtNombre;
                            query.TxtUser = model.TxtUser;
                            query.TxtPassword = model.TxtPassword;

                            db.SaveChanges();


                            return RedirectToAction("Index");
                        }

                    }
                    else
                    {
                        ModelState.AddModelError("", "No se puedo obtener información del usuario.");

                    }

                    
                }
                model.ListaRoles = new SelectList(GetRoles(), "CodRol", "TxtDesc");


                return View(model);
            }
            catch (Exception ex)
            {
               ModelState.AddModelError("", ex.Message);

                return View(model);
            }
        }

        public ActionResult Delete(int codUsuario)
        {
            var model = GetUsuario(codUsuario);

            model.ListaRoles = new SelectList(GetRoles(), "CodRol", "TxtDesc");


            return View(model);
        }

        // POST: /Clientes/Delete/5
        [HttpPost]
        public ActionResult Delete(Models.UsuarioModel model, int codUsuario)
        {
            try
            {
                ContextDb.AppDbContext db = new ContextDb.AppDbContext();

                var query = db.TUsers.Where(w => w.CodUsuario == codUsuario).FirstOrDefault();

                if(query!=null)
                {
                    db.Remove(query);
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "No se puede obtener los datos del usuario.");

                    return View(model);
                }
                
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);

                return View(model);
            }
        }

    }
}
