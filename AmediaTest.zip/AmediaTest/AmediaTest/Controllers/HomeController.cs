﻿using AmediaTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AmediaTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult InicioVisitante()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public ActionResult Index(LoginModel model)
        {
            try
            {
                
                if (ModelState.IsValid)
                {
                    ContextDb.AppDbContext db = new ContextDb.AppDbContext();


                    var nombreUsuario = model.TxtUser;
                    var password = model.TxtPassword;

                    var query = db.TUsers.Where(w => w.TxtUser == nombreUsuario && w.TxtPassword == password).FirstOrDefault();

                    if (query != null)
                    {

                        if (query.CodRol == 1)
                            return RedirectToAction("Index","Usuario", model);
                        else
                            return View("InicioVisitante");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Error con usuario o password.");

                        return View(model);
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);

                return View(model);
            }
        }
    }
}
