﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AmediaTest.Models
{
    public class UsuarioModel
    {
        public List<UsuarioModel> ListaUsuarios { get; set; }

        public int CodUsuario { get; set; }

        [DisplayName("Rol")]
        public SelectList ListaRoles { get; set; }
        

        [Required]
        [DisplayName("Usuario")] 
        public string TxtUser { get; set; }


        [Required]
        [DisplayName("Password")]
        public string TxtPassword { get; set; }

        [Required]
        [DisplayName("Nombre")]
        public string TxtNombre { get; set; }

        [Required]
        [DisplayName("Apellido")]
        public string TxtApellido { get; set; }

        [Required]
        [DisplayName("NroDoc")]
        public string NroDoc { get; set; }

        [Required]
        [DisplayName("Rol")]
        public int? CodRol { get; set; }

        [DisplayName("Activo")]
        public Boolean SnActivo { get; set; }

        [DisplayName("Rol")]
        public string RolDesc { get; set; }
    }


}