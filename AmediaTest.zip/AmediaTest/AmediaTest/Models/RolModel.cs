﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AmediaTest.Models
{
    public class RolModel
    {
        [Required]
        [DisplayName("Código Rol")]
        public string cod_rol { get; set; }

        [Required]
        [DisplayName("Dec Rol")]
        public string txt_desc { get; set; }

        [Required]
        [DisplayName("Activo")]
        public int sn_activo { get; set; }

        
    }
}
